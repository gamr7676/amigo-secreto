// Lógica del sorteo de Amigo Secreto
const state = {
  people: [],
  selected: null
};

const els = {
  form: document.getElementById('add-form'),
  input: document.getElementById('nameInput'),
  feedback: document.getElementById('feedback'),
  list: document.getElementById('namesList'),
  drawBtn: document.getElementById('drawBtn'),
  resetBtn: document.getElementById('resetBtn'),
  result: document.getElementById('result')
};

function setFeedback(msg, type = 'info') {
  els.feedback.textContent = msg || '';
}

function renderList() {
  els.list.innerHTML = '';
  if (state.people.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'Aún no hay participantes.';
    els.list.appendChild(li);
    return;
  }
  state.people.forEach((name, idx) => {
    const li = document.createElement('li');

    const indexBadge = document.createElement('span');
    indexBadge.className = 'badge';
    indexBadge.textContent = String(idx + 1).padStart(2, '0');

    const nameSpan = document.createElement('span');
    nameSpan.textContent = name;
    if (state.selected === name) {
      nameSpan.style.fontWeight = '700';
    }

    const removeBtn = document.createElement('button');
    removeBtn.className = 'remove-btn';
    removeBtn.type = 'button';
    removeBtn.textContent = 'Eliminar';
    removeBtn.addEventListener('click', () => removeName(idx));

    li.appendChild(indexBadge);
    li.appendChild(nameSpan);
    li.appendChild(removeBtn);
    els.list.appendChild(li);
  });
}

function addName(raw) {
  const name = (raw || '').trim();
  if (!name) {
    setFeedback('Escribe un nombre válido.');
    return;
  }
  const normalized = name.toLocaleLowerCase();
  const exists = state.people.some(p => p.toLocaleLowerCase() === normalized);
  if (exists) {
    setFeedback('Ese nombre ya está en la lista.');
    return;
  }
  state.people.push(name);
  els.input.value = '';
  setFeedback(`Se agregó: ${name}`);
  renderList();
}

function removeName(index) {
  const removed = state.people.splice(index, 1)[0];
  if (removed === state.selected) {
    state.selected = null;
    els.result.textContent = '';
  }
  setFeedback(`Se eliminó: ${removed}`);
  renderList();
}

function draw() {
  if (state.people.length < 2) {
    setFeedback('Necesitas al menos 2 participantes para sortear.');
    return;
  }
  const r = Math.floor(Math.random() * state.people.length);
  const winner = state.people[r];
  state.selected = winner;
  els.result.textContent = `🎉 El amigo secreto es: ${winner}`;
  setFeedback('¡Sorteo realizado!');
  renderList();
}

function resetAll() {
  state.people = [];
  state.selected = null;
  els.result.textContent = '';
  setFeedback('Lista reiniciada.');
  renderList();
}

// Eventos
els.form.addEventListener('submit', (e) => {
  e.preventDefault();
  addName(els.input.value);
});

els.drawBtn.addEventListener('click', draw);
els.resetBtn.addEventListener('click', resetAll);

// Soporta Enter para agregar más rápido
els.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    addName(els.input.value);
  }
});

// Primer render
renderList();
