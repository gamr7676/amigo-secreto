# 🎁 Amigo Secreto (Starter)

Aplicación web simple para ingresar nombres y realizar un sorteo aleatorio del **amigo secreto**.

## 🚀 Cómo usar
1. Abre `index.html` en tu navegador y agrega nombres en la caja de texto.
2. Presiona **Agregar** para sumar participantes a la lista.
3. Cuando tengas al menos 2, haz clic en **SORTEAR**.
4. Puedes **eliminar** nombres o **reiniciar** la lista.

## 🗂 Estructura
```
.
├── index.html
├── style.css
└── app.js
```

## 🧩 Tecnologías
- HTML, CSS y JavaScript puro (sin frameworks)

## 📦 Deploy en GitHub Pages (opcional)
1. Sube estos archivos a un repositorio público.
2. Ve a **Settings → Pages**.
3. En **Source**, elige *Deploy from a branch* y selecciona la rama `main` y la carpeta `/ (root)`.
4. Guarda. GitHub te mostrará la URL pública del sitio.

---

Hecho para aprendizaje ✨
